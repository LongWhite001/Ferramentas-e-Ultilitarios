powershell -ExecutionPolicy Bypass -File corrigir_preview_pdf-2.ps1
pause