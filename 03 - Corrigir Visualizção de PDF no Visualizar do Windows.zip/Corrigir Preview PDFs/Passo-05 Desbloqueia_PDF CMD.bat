@echo off

powershell.exe Unblock-File -Path "%userprofile%\Downloads\*.pdf"
powershell.exe Unblock-File -Path "%userprofile%\Documents\*.pdf"
powershell.exe Unblock-File -Path "%userprofile%\Videos\*.pdf"
powershell.exe Unblock-File -Path "%userprofile%\Pictures\*.pdf"
powershell.exe Unblock-File -Path "%userprofile%\Desktop\*.pdf"
pause