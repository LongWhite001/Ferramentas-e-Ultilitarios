cd C:\Scripts
powershell -ExecutionPolicy Bypass -File corrigir_preview_pdf-3.ps1
pause