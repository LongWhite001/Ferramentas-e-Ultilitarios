# Corrigir visualização de PDFs no Painel de Visualização do Windows
# Remove bloqueio de arquivos baixados da internet (Mark of the Web)

Write-Host "Iniciando correção de PDFs..." -ForegroundColor Cyan

# Caminho base do usuário atual
$UserPath = $env:USERPROFILE

Write-Host "Escaneando arquivos PDF em: $UserPath"

# Localiza todos os PDFs e remove bloqueio
Get-ChildItem -Path $UserPath -Recurse -Filter *.pdf -ErrorAction SilentlyContinue | ForEach-Object {
    
    try {
        Unblock-File -Path $_.FullName
        Write-Host "Desbloqueado: $($_.FullName)" -ForegroundColor Green
    }
    catch {
        Write-Host "Erro ao processar: $($_.FullName)" -ForegroundColor Red
    }

}

Write-Host "Processo conclui�do." -ForegroundColor Cyan