@echo off
Title Remover Atualizacoes do Windows.

echo Corrigir erros de Preview PDFs.
echo.
Timeout /t 5
cls
echo Tabela de Atualizacao do Windows Versao 10 e 11.
echo.

wmic qfe list brief /format:table

echo Removendo Atualizacoes KB5066793 e KB5066835.
echo Sera Preciso Reiniciar o Computador a Cada Remocao.
timeout /t 5
cls
wusa /uninstall /KB5066793

timeout /t 5

wusa /uninstall /KB5066835
timeout /t 5

Shutdown -r -t 100