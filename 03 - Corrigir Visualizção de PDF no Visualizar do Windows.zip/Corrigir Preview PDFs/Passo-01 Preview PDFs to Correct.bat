cd C:\Scripts
powershell -ExecutionPolicy Bypass -File corrigir_preview_pdf.ps1
pause

