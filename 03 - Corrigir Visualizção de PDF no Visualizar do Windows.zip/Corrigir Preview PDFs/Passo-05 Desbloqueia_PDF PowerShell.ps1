Unblock-File -Path "%userprofile%\Downloads\*.pdf"
Unblock-File -Path "%userprofile%\Documents\*.pdf"
Unblock-File -Path "%userprofile%\Videos\*.pdf"
Unblock-File -Path "%userprofile%\Pictures\*.pdf"
Unblock-File -Path "%userprofile%\Desktop\*.pdf"
pause