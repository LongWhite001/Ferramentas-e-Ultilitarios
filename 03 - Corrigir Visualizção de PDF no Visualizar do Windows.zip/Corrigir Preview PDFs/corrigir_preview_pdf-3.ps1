
Get-ChildItem -Path "C:\Users\SEU-Usuario\Area de Trabalho\pdf\*.pdf" | Unblock-File
Get-ChildItem -Path "C:\Users\SEU-Usuario\Downloads\pdf\*.pdf" | Unblock-File
Get-ChildItem -Path "C:\Users\SEU-Usuario\Documentos\pdf\*.pdf" | Unblock-File
echo.
Get-ChildItem -Path "C:\Users\SEU-Usuario\Desktop\pdf\*.pdf" | Unblock-File
Get-ChildItem -Path "C:\Users\SEU-Usuario\Downloads\pdf\*.pdf" | Unblock-File
Get-ChildItem -Path "C:\Users\SEU-Usuario\Documents\pdf\*.pdf" | Unblock-File
