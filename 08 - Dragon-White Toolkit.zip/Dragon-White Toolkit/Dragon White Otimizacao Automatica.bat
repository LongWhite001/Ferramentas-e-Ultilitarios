@echo off
chcp 65001 >nul
title Otimizar Windows

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Otimizar.Windows"
for /l %%i in (0,1,17) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls


:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Agendar.CHK."
for /l %%i in (0,1,13) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls
chkdsk c: /f
echo Agendado.
timeout /t 3 >nul
cls

chcp 65001 >nul

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=TRIM"
for /l %%i in (0,1,04) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls

chcp 65001 >nul

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Executando.TRIM.em.todos.os.discos..."
for /l %%i in (0,1,38) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls

powershell.exe Optimize-Volume -DriveLetter C -ReTrim -Verbose
fsutil behavior set DisableDeleteNotify 0
echo TRIM realizado com sucesso!
timeout /t 3 >nul
cls

chcp 65001 >nul

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Limpando.Arquivos.TEMPORARIOS.e.LIXEIRA."
for /l %%i in (0,1,41) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls

del /s /f /q "%temp%\*" >nul 2>&1
del /s /f /q "C:\Windows\Temp\*" >nul 2>&1
rd /s /q "%temp%" >nul 2>&1
rd /s /q "C:\Windows\Temp" >nul 2>&1
echo Simulando esvaziamento da Lixeira...
PowerShell.exe -NoProfile -Command "Clear-RecycleBin -Force" 2>nul
echo Limpeza concluída!

echo.
timeout /t 3 >nul
cls


chcp 65001 >nul

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Limpeza.de.Disco"
for /l %%i in (0,1,17) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls

Cleanmgr
cleanmgr /sagerun:1
echo.
timeout /t 3 >nul
cls

chcp 65001 >nul

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Limpar.PREFETCH."
for /l %%i in (0,1,17) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls

del /q /f C:\Windows\Prefetch\*.* >nul 2>&1
echo Prefetch limpo!
timeout /t 3 >nul
cls

chcp 65001 >nul

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Desfragmentar.SSD/HDD"
for /l %%i in (0,1,22) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 3 >nul
cls

defrag C:
defrag D:
defrag E:
echo Concluido.
cls

timeout /t 3 >nul

echo Scannow.
cls
sfc /scannow
echo Concluido.

timeout /t 3 >nul
cls 

chcp 65001 >nul

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Saindo.e.Reicinicando.em..."
for /l %%i in (0,1,28) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 5 

shutdown -r -t 000
