@echo off
chcp 65001 >nul
title Dragon-White Otimização e Reparo

:: Função para escrever texto lentamente
setlocal enabledelayedexpansion
set "texto=Dragon-White"
for /l %%i in (0,1,11) do (
    set "char=!texto:~%%i,1!"
    <nul set /p="!char!"
    ping -n 1 -w 120 localhost >nul
)
echo.
timeout /t 1 >nul
cls

:MENU
echo ==================================================
echo            Dragon-White Otimizacao e Reparo
echo ==================================================
echo [1] Otimizar SSD (TRIM)
echo [2] Limpeza de Arquivos Temporarios e Lixeira
echo [3] Limpeza de Disco
echo [4] Limpar Prefetch
echo [5] Desfragmentar Disco (SSD)
echo [6] Parar Servico SYSMAIN
echo [7] Menu de Reparo
echo [0] Sair
echo ==================================================
set /p op="Escolha uma opção: "

if "%op%"=="1" goto TRIM
if "%op%"=="2" goto TEMP
if "%op%"=="3" goto DISK
if "%op%"=="4" goto PREFETCH
if "%op%"=="5" goto DEFRAG
if "%op%"=="6" goto SYSMAIN
if "%op%"=="7" goto REPARO
if "%op%"=="0" goto FIM
goto MENU

:TRIM
echo.
echo Executando TRIM em todos os discos...
powershell.exe Optimize-Volume -DriveLetter C -ReTrim -Verbose
fsutil behavior set DisableDeleteNotify 0
echo TRIM realizado com sucesso!
pause
cls
goto MENU

:TEMP
echo.
echo Limpando arquivos temporários e lixeira...
del /s /f /q "%temp%\*" >nul 2>&1
del /s /f /q "C:\Windows\Temp\*" >nul 2>&1
rd /s /q "%temp%" >nul 2>&1
rd /s /q "C:\Windows\Temp" >nul 2>&1
echo Simulando esvaziamento da Lixeira...
PowerShell.exe -NoProfile -Command "Clear-RecycleBin -Force" 2>nul
echo Limpeza concluída!
pause
cls
goto MENU

:DISK
echo.
echo Abrindo utilitário de limpeza de disco...
cleanmgr
pause
cls
goto MENU

:PREFETCH
echo.
echo Limpando Prefetch...
del /q /f C:\Windows\Prefetch\*.* >nul 2>&1
echo Prefetch limpo!
pause
cls
goto MENU

:DEFRAG
echo.
Defrag c:
pause
cls
goto MENU

:SYSMAIN
echo.
echo Serviços recomendados para parar com segurança:
echo 1 - Sysmain
echo --------------------------------------------------
set /p serv="Digite o número do serviço que deseja parar (ou 0 para voltar): "
net.exe stop sysmain
sc config sysmain start=disabled
if "%serv%"=="0" cls & goto MENU
if not defined svc echo Opção inválida!& pause & cls & goto SYSMAIN
net stop "%svc%"
echo Serviço %svc% parado!
set svc=
pause
cls
goto menu

:REPARO
echo =================== Menu de Reparo ===================
echo [1] SFC /Scannow (Reparo Simples)
echo [2] CHKDSK C: /F (Reparo Rápido)
echo [3] CHKDSK C: /R (Reparo Total Demorado)
echo [4] Sair
echo [0] Voltar
echo ======================================================
set /p rep="Escolha uma opção: "
if "%rep%"=="1" goto SFC
if "%rep%"=="2" goto CHKDSKF
if "%rep%"=="3" goto CHKDSKR
if "%rep%"=="4" goto EXIT
if "%rep%"=="0" cls & goto MENU
goto REPARO

:SFC
echo Rodando SFC /Scannow...
sfc /scannow
pause
cls
goto REPARO

:CHKDSKF
echo Rodando CHKDSK C: /F...
chkdsk C: /F
pause
cls
goto REPARO

:CHKDSKR
echo Rodando CHKDSK C: /R...
chkdsk C: /R
pause
cls
goto REPARO

:Sair e Fechar
echo Saindo em
timeout /t 3
exit
pause
cls
goto REPARO

:FIM
cls
echo.
echo          ╔══════════════════════════════════════╗
echo          ║                                      ║                ║
echo          ║        Dragon-White                  ║
echo          ║           (白龍)                     ║
echo          ║                                      ║
echo          ╚══════════════════════════════════════╝
echo.
echo           Pressione qualquer tecla para sair...
pause >nul
exit